﻿from flask import Flask
from infra.db import Database
from controllers.user_controller import UserController
from controllers.admin_controller import AdminController
from controllers.appointment_controller import AppointmentController  # Importa o AppointmentController
from controllers.financial_entry_controller import FinancialEntryController
from controllers.service_controller import ServiceController

def create_app():
    app = Flask(__name__, template_folder='views')
    app.secret_key = '8ZnwnjFmX]5WNY\'\'2-u)'

    # Inicializações e configurações
    Database.initialize_database(app)  # Inicializa o banco de dados
    UserController.setup_user_routes(app)  # Configura as rotas de usuário
    AdminController.setup_admin_routes(app)  # Configura as rotas de administração
    AppointmentController.setup_appointment_routes(app)  # Configura as rotas de agendamento
    FinancialEntryController.setup_financial_routes(app) # Configura as rotas do financeiro
    ServiceController.setup_service_routes(app) # Configura as rotas dos serviços do salão

    return app
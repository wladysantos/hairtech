﻿import sqlite3
from contextlib import contextmanager
from werkzeug.security import generate_password_hash

class Database:
    DB_PATH = 'data/database.db'

    @staticmethod
    @contextmanager
    def get_db_connection():
        """Context manager para obter uma conexão com o banco de dados."""
        conn = None
        try:
            conn = sqlite3.connect(Database.DB_PATH)
            conn.row_factory = sqlite3.Row  # Configura o cursor para retornar dicionários
            yield conn
        except sqlite3.Error as e:
            # Tratamento de erro na conexão com o banco de dados
            print(f"Database connection error: {e}")
        finally:
            if conn:
                conn.close()

    @staticmethod
    def execute_query(query, params=()):
        """Executa uma consulta SELECT no banco de dados."""
        try:
            with Database.get_db_connection() as conn:
                cursor = conn.execute(query, params)
                results = [dict(row) for row in cursor.fetchall()]  # Retorna resultados como lista de dicionários
                return results
        except sqlite3.Error as e:
            # Tratamento de erro de execução de consulta
            print(f"Query execution error: {e}")
        except Exception as e:
            # Tratamento de erros inesperados
            print(f"Unexpected error during query execution: {e}")
        return None

    @staticmethod
    def execute_commit(query, params=()):
        """Executa uma consulta que modifica o banco de dados (INSERT, UPDATE, DELETE)."""
        try:
            with Database.get_db_connection() as conn:
                conn.execute(query, params)
                conn.commit()
            return True
        except sqlite3.Error as e:
            # Tratamento de erro durante o commit
            print(f"An error occurred during commit: {e}")
        return False

    @staticmethod
    def initialize_database(app):
        """Inicializa o banco de dados e cria as tabelas se elas não existirem."""
        with app.app_context():
            # Criação da tabela de usuários
            Database.execute_commit('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    email TEXT UNIQUE,
                    fullname TEXT UNIQUE,
                    password TEXT,
                    is_admin BOOLEAN DEFAULT 0,
                    is_active BOOLEAN DEFAULT 1,
                    phone TEXT,
                    address TEXT
                )
            ''')

            # Criação da tabela de agendamentos
            Database.execute_commit('''
                CREATE TABLE IF NOT EXISTS appointments (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER,
                    datetime DATETIME,
                    service TEXT,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            ''')

            # Criação da tabela de entradas financeiras
            Database.execute_commit('''
                CREATE TABLE IF NOT EXISTS financial_entries (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER,
                    entry_date DATE,
                    description TEXT,
                    amount REAL,
                    entry_type TEXT CHECK(entry_type IN ('receita', 'despesa')),
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            ''')

            # Criação da tabela de serviços
            Database.execute_commit('''
                CREATE TABLE IF NOT EXISTS services (
                    id INTEGER PRIMARY KEY,
                    name TEXT UNIQUE,
                    price REAL
                )
            ''')

            # Inserir usuário administrador padrão
            hashed_password = generate_password_hash('admin')  # Gera um hash seguro para a senha "admin"
            Database.execute_commit('''
                INSERT INTO users (email, fullname, password, is_admin, is_active)
                VALUES (?, ?, ?, ?, ?)
            ''', ('admin@hairtech.com', 'admin', hashed_password, True, True))

            # Inserir usuários padrão com admin=False
            users = [
                ('wladmyr@hairtech.com', 'Wladmyr Santos'),
                ('aline@hairtech.com', 'Aline Morais'),
                ('daiana@hairtech.com', 'Daiana Araujo'),
                ('kelly@hairtech.com', 'Kelly Reinol'),
                ('vitor@hairtech.com', 'Vitor Lima')
            ]

            for email, fullname in users:
                Database.execute_commit('''
                    INSERT INTO users (email, fullname, password, is_admin, is_active)
                    VALUES (?, ?, ?, ?, ?)
                ''', (email, fullname, hashed_password, False, True))

            # Inserir serviços padrão na tabela de serviços
            services = [
                ('Limpeza de pele', 150.00),
                ('Hidratação facial', 120.00),
                ('Esfoliação', 80.00),
                ('Drenagem linfática', 200.00),
                ('Maquiagem', 180.00),
                ('Design de sobrancelhas', 50.00),
                ('Massagem relaxante', 250.00),
                ('Massagem terapêutica', 300.00),
                ('Corte', 70.00),
                ('Barba', 40.00),
                ('Luzes', 350.00),
                ('Escova', 100.00),
                ('Alisamento', 400.00),
                ('Corte infantil', 50.00)
            ]

            for name, price in services:
                Database.execute_commit('''
                    INSERT INTO services (name, price)
                    VALUES (?, ?)
                ''', (name, price))

        print("Database and tables initialized successfully")

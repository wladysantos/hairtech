document.addEventListener('DOMContentLoaded', function () {
    // Referências aos elementos do DOM
    const calendarEl = document.getElementById('calendar');
    const newEditAppointmentModal = document.getElementById('newEditAppointmentModal');
    const actionButton = document.getElementById('actionButton');
    const serviceSelect = document.getElementById('serviceSelect');
    const deleteAppointmentButton = document.getElementById('deleteAppointment');
    const customerSelect = document.getElementById('customerSelect');

    // Configuração das URLs da API
    const API_URLS = {
        GET_APPOINTMENTS: '/get_appointments',
        GET_ALL_APPOINTMENTS: '/admin/get_all_appointments',
        ADD_APPOINTMENT: '/add_appointment',
        UPDATE_APPOINTMENT: '/update_appointment',
        DELETE_APPOINTMENT: '/delete_appointment',
        GET_CUSTOMERS: '/admin/get_customers'
    };

    // Inicialização do calendário
    let calendar = configureFullCalendarOptions(calendarEl);
    calendar.render();

    // Configuração do FullCalendar
    function configureFullCalendarOptions(calendarElement) {
        return new FullCalendar.Calendar(calendarElement, {
            themeSystem: 'bootstrap5',
            headerToolbar: {
                left: 'today prev,next',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
            },
            locale: 'pt-br',
            initialView: 'dayGridMonth',
            slotMinTime: '08:00:00',
            slotMaxTime: '20:00:00',
            height: 'auto',
            contentHeight: 'auto',
            expandRows: true,
            fixedWeekCount: false,
            showNonCurrentDates: true,
            eventTimeFormat: {
                hour: '2-digit',
                minute: '2-digit',
                meridiem: false
            },
            dayMaxEventRows: 3,
            selectable: true,
            dateClick: handleDateClick,
            events: IS_ADMIN ? API_URLS.GET_ALL_APPOINTMENTS : API_URLS.GET_APPOINTMENTS,
            eventClick: handleAppointment,
        });
    }

    // Função para abrir o modal no modo de "Novo Agendamento"
    function handleDateClick(info) {
        const currentDate = new Date();
        const dateObj = new Date(info.dateStr + "T" + currentDate.toTimeString().split(' ')[0]);

        document.getElementById('datetimeInput').value = formatDateTime(dateObj);

        populateServiceSelect();
        populateCustomerSelect();

        configureModal('Novo Agendamento', 'Confirmar Agendamento', handleNewAppointment);

        if (deleteAppointmentButton) {
            deleteAppointmentButton.style.display = 'none';
        }

        showModal(newEditAppointmentModal);
    }

    // Função para abrir o modal no modo de "Edição de Agendamento"
    function handleAppointment(info) {
        const dateObj = new Date(info.event.start);

        document.getElementById('datetimeInput').value = formatDateTime(dateObj);

        const currentService = info.event.title.split(' - ')[0].toLowerCase();
        populateServiceSelect(currentService);
        populateCustomerSelect(info.event.extendedProps.customer_name);

        configureModal('Editar Agendamento', 'Salvar Alterações', () => handleEditAppointment(info.event.id));

        if (IS_ADMIN && deleteAppointmentButton) {
            deleteAppointmentButton.style.display = 'inline-block';
            deleteAppointmentButton.onclick = function () {
                handleDeleteAppointment(info.event.id);
            };
        } else {
            deleteAppointmentButton.style.display = 'none';
        }

        showModal(newEditAppointmentModal);
    }

    // Função para preencher o campo de seleção de clientes
    function populateCustomerSelect(selectedCustomer = '') {
        customerSelect.innerHTML = '';

        if (IS_ADMIN) {
            fetch(API_URLS.GET_CUSTOMERS)
                .then(response => response.json())
                .then(customers => {
                    customers.forEach(customer => {
                        const option = document.createElement('option');
                        option.value = customer.id;
                        option.textContent = customer.fullname;
                        if (selectedCustomer && customer.fullname === selectedCustomer) {
                            option.selected = true;
                        }
                        customerSelect.appendChild(option);
                    });
                    customerSelect.disabled = false;
                });
        } else {
            const option = document.createElement('option');
            option.value = USER_ID;  // Use o ID do usuário logado
            option.textContent = USER_FULLNAME;  // Use o nome completo do usuário logado
            option.selected = true;
            customerSelect.appendChild(option);
            customerSelect.disabled = true;
        }
    }

    // Função para configurar o modal
    function configureModal(title, buttonText, onClickAction) {
        document.getElementById('newEditAppointmentModalLabel').textContent = title;
        actionButton.textContent = buttonText;
        actionButton.onclick = function (event) {
            event.preventDefault();

            if (serviceSelect.value === '') {
                showAlert('warning', 'Atenção!', 'Por favor, selecione um serviço antes de continuar.');
                return;
            }

            // Valida a data e hora selecionadas antes de confirmar o agendamento
            validateDateTime(onClickAction);
        };
    }

    // Função para validar a data e hora selecionadas
    function validateDateTime(callback) {
        const datetimeInput = document.getElementById('datetimeInput').value;
        const selectedDate = parseDateTime(datetimeInput); // Converter para objeto Date
        const currentDate = new Date();

        if (!selectedDate) {
            Swal.fire({
                title: 'Erro de Data!',
                text: 'Data e hora inválidas.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            return;
        }

        if (!IS_ADMIN) {
            // Se não for administrador, aplica restrições de data e hora
            if (selectedDate < currentDate) {
                Swal.fire({
                    title: 'Período indisponível!',
                    text: 'Agendamento indisponível para o dia e horário selecionados.',
                    icon: 'warning',
                    confirmButtonText: 'OK'
                });
                return;
            }

            const hours = selectedDate.getHours();
            const minutes = selectedDate.getMinutes();

            if (hours < 8 || (hours === 20 && minutes > 0) || hours > 20) {
                Swal.fire({
                    title: 'Fora do horário comercial!',
                    text: 'O horário selecionado está fora do horário comercial (08:00 - 20:00).',
                    icon: 'warning',
                    confirmButtonText: 'OK'
                });
                return;
            }
        }

        // Executa o callback para confirmar o agendamento
        callback();
    }

    // Função para converter a string de data e hora em pt-BR para um objeto Date
    function parseDateTime(datetimeStr) {
        const [datePart, timePart] = datetimeStr.split(' ');
        const [day, month, year] = datePart.split('/').map(Number);
        const [hours, minutes] = timePart.split(':').map(Number);

        return new Date(year, month - 1, day, hours, minutes);
    }

    // Função para mostrar o modal
    function showModal(modalElement) {
        let modal = new bootstrap.Modal(modalElement);
        modal.show();
    }

    // Função para popular o campo de seleção de serviço
    function populateServiceSelect(selectedService = null) {
        serviceSelect.innerHTML = '';

        const emptyOption = document.createElement('option');
        emptyOption.value = '';
        emptyOption.textContent = 'Selecione um serviço';
        emptyOption.hidden = true;
        emptyOption.selected = true;
        serviceSelect.appendChild(emptyOption);

        // Fazer uma chamada à API para obter os serviços do banco de dados
        fetch('/services')
            .then(response => response.json())
            .then(services => {
                services.forEach(service => {
                    const option = document.createElement('option');
                    option.value = service.name.toLowerCase();
                    option.textContent = service.name;
                    if (selectedService === service.name.toLowerCase()) {
                        option.selected = true;
                    }
                    serviceSelect.appendChild(option);
                });
            })
            .catch(error => {
                console.error('Erro ao recuperar serviços:', error);
            });

        serviceSelect.required = true;
    }

    // Função para manipular o envio de um novo agendamento
    function handleNewAppointment() {
        const formData = {
            datetime: document.getElementById('datetimeInput').value,
            service: serviceSelect.value,
            customer: getSelectedCustomerId()
        };
        handleAppointmentRequest(
            API_URLS.ADD_APPOINTMENT,
            'POST',
            formData,
            'Agendamento adicionado com sucesso!',
            'Erro ao adicionar agendamento',
            'newEditAppointmentModal'
        );
    }

    // Função para manipular a edição de um agendamento
    function handleEditAppointment(appointmentId) {
        const formData = {
            id: appointmentId,
            datetime: document.getElementById('datetimeInput').value,
            service: serviceSelect.value,
            customer: getSelectedCustomerId()
        };

        handleAppointmentRequest(
            API_URLS.UPDATE_APPOINTMENT,
            'POST',
            formData,
            'Agendamento atualizado com sucesso!',
            'Erro ao atualizar agendamento',
            'newEditAppointmentModal'
        );
    }

    // Função para obter o ID do cliente selecionado
    function getSelectedCustomerId() {
        return customerSelect.value;
    }

    // Função genérica para lidar com requisições de agendamento
    function handleAppointmentRequest(url, method, formData, successMessage, errorMessage, modalId) {
        fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        })
        .then(response => response.json().then(data => ({ status: response.status, body: data })))
        .then(({ status, body }) => {
            if (status === 200 && body.status === 'success') {
                showAlert('success', 'Sucesso!', successMessage);
                calendar.refetchEvents();
                const modal = bootstrap.Modal.getInstance(document.getElementById(modalId));
                modal.hide();
            } else {
                showAlert('error', 'Erro!', `${errorMessage}: ${body.message}`);
            }
        })
        .catch(error => {
            showAlert('error', 'Erro!', 'Erro ao tentar realizar a ação.');
        });
    }

    // Função para manipular a exclusão de um agendamento
    function handleDeleteAppointment(appointmentId) {
        handleAppointmentRequest(
            API_URLS.DELETE_APPOINTMENT,
            'POST',
            { id: appointmentId },
            'Agendamento excluído com sucesso!',
            'Erro ao excluir agendamento',
            'newEditAppointmentModal'
        );
    }

    // Função para mostrar alertas usando SweetAlert2
    function showAlert(type, title, message) {
        Swal.fire({
            icon: type,
            title: title,
            text: message,
            customClass: {
                confirmButton: 'btn btn-primary'
            },
            buttonsStyling: false
        });
    }

    // Configuração do Flatpickr para o campo de data e hora
    configureFlatpickr("#datetimeInput");

    function configureFlatpickr(selector) {
        flatpickr(selector, {
            locale: "pt",
            dateFormat: "d/m/Y H:i",
            enableTime: true,
            time_24hr: true,
            minTime: "08:00",
            maxTime: "20:00",
            minuteIncrement: 5,
            allowInput: true,
            defaultDate: new Date(),
            position: "above center",
            onOpen: function (selectedDates, dateStr, instance) {
                const currentValue = document.querySelector(selector).value || new Date();
                instance.setDate(currentValue);
            },
            onClose: function (selectedDates, dateStr, instance) {
                const selectedDate = selectedDates[0];
                if (selectedDate && selectedDate < new Date() && !IS_ADMIN) {
                    Swal.fire({
                        title: 'Atenção!',
                        text: 'Agendamento indisponível para o dia e horário selecionados.',
                        icon: 'warning',
                        confirmButtonText: 'OK'
                    }).then(() => {
                        instance.clear();
                    });
                }
            },
        });
    }

    // Função utilitária para formatar data e hora
    function formatDateTime(dateObj) {
        const formattedDate = dateObj.toLocaleDateString('pt-BR');
        const formattedTime = dateObj.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        return `${formattedDate} ${formattedTime}`;
    }
});
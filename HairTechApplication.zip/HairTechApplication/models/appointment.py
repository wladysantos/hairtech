﻿from infra.db import Database
from datetime import datetime


class Appointment:
    def __init__(self, user_id, datetime_str, service):
        """Inicializa um objeto de agendamento."""
        self.user_id = user_id
        self.datetime_str = datetime_str
        self.service = service

    @staticmethod
    def add_appointment(user_id, datetime_str, service):
        """Adiciona um novo agendamento para um usuário."""
        try:
            # Converte a string de data e hora para o formato adequado
            datetime_obj = datetime.strptime(datetime_str, '%d/%m/%Y %H:%M')
            datetime_formatted = datetime_obj.strftime('%Y-%m-%d %H:%M:%S')
        except ValueError:
            return False, 'Invalid date format!'

        # Tenta adicionar o agendamento ao banco de dados
        success = Database.execute_commit('''
            INSERT INTO appointments (user_id, datetime, service) VALUES (?, ?, ?)
        ''', (user_id, datetime_formatted, service))

        return (True, 'Appointment added successfully!') if success else (False, 'Failed to add appointment!')

    @staticmethod
    def get_appointments_by_user(user_id):
        """Obtém todos os agendamentos para um usuário específico."""
        appointments = Database.execute_query('''
            SELECT a.id, a.datetime, UPPER(a.service) as service, UPPER(u.fullname) as customer_name
            FROM appointments a
            JOIN users u ON a.user_id = u.id
            WHERE a.user_id = ?
        ''', (user_id,))

        # Formata os resultados
        events = []
        for appointment in appointments:
            try:
                datetime_obj = datetime.strptime(appointment['datetime'], '%Y-%m-%d %H:%M:%S')
                events.append({
                    'id': appointment['id'],
                    'title': f"{appointment['service']} - {appointment['customer_name']}",
                    'start': datetime_obj.strftime('%Y-%m-%dT%H:%M:%S'),
                    'customer_name': appointment['customer_name']
                })
            except (ValueError, TypeError):
                # Ignora erros de formato de data/hora
                continue

        return events

    @staticmethod
    def update_appointment(appointment_id, user_id, datetime_str, service):
        """Atualiza um agendamento existente."""
        try:
            # Converte a string de data e hora para o formato adequado
            datetime_obj = datetime.strptime(datetime_str, '%d/%m/%Y %H:%M')
            datetime_formatted = datetime_obj.strftime('%Y-%m-%d %H:%M:%S')
        except ValueError:
            return False, 'Invalid date format!'

        # Atualiza o agendamento incluindo o campo user_id
        success = Database.execute_commit('''
            UPDATE appointments 
            SET datetime = ?, service = ?, user_id = ? 
            WHERE id = ?
        ''', (datetime_formatted, service, user_id, appointment_id))

        return (True, 'Appointment updated successfully!') if success else (False, 'Failed to update appointment!')

    @staticmethod
    def delete_appointment(appointment_id):
        """Deleta um agendamento existente."""
        success = Database.execute_commit('''
            DELETE FROM appointments WHERE id = ?
        ''', (appointment_id,))

        return (True, 'Appointment deleted successfully!') if success else (False, 'Failed to delete appointment!')

    @staticmethod
    def get_appointment_by_id(appointment_id):
        """Obtém um agendamento específico pelo ID."""
        appointment = Database.execute_query('''
            SELECT * FROM appointments WHERE id = ?
        ''', (appointment_id,))
        return appointment[0] if appointment else None

    @staticmethod
    def get_all_appointments():
        """Obtém todos os agendamentos do banco de dados."""
        try:
            appointments = Database.execute_query('''
                SELECT a.id, a.datetime, UPPER(a.service) AS service, u.fullname AS customer_name
                FROM appointments a
                JOIN users u ON a.user_id = u.id
            ''')

            if not appointments:
                return False, 'No appointments found or database error.'

            all_appointments = [
                {
                    'id': appointment['id'],
                    'title': f"{appointment['service']} - {appointment['customer_name']}",
                    'start': appointment['datetime'],
                    'extendedProps': {'customer_name': appointment['customer_name']}
                }
                for appointment in appointments
            ]

            return True, all_appointments
        except Exception:
            # Tratamento de erro ao obter todos os agendamentos
            return False, 'Internal Server Error.'
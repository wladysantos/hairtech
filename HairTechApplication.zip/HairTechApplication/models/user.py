﻿from infra.db import Database
from werkzeug.security import generate_password_hash, check_password_hash

class User:
    def __init__(self, email, fullname, password, is_admin=False, is_active=True, phone=None, address=None):
        """Inicializa um objeto de usuário."""
        self.email = email
        self.fullname = fullname
        self.password = password
        self.is_admin = is_admin
        self.is_active = is_active
        self.phone = phone
        self.address = address

    @staticmethod
    def authenticate(email, password):
        """Autentica usuários com base no e-mail e senha fornecidos."""
        user = Database.execute_query(
            "SELECT id, email, fullname, password, is_admin, is_active, phone, address FROM users WHERE email=? AND is_active=1",
            (email,)
        )

        if user:
            stored_password_hash = user[0]['password']
            if check_password_hash(stored_password_hash, password):
                # Retorna os dados do usuário se a senha estiver correta
                return {
                    'id': user[0]['id'],
                    'email': user[0]['email'],
                    'fullname': user[0]['fullname'],
                    'is_admin': user[0]['is_admin'],
                    'is_active': user[0]['is_active'],
                    'phone': user[0]['phone'],
                    'address': user[0]['address']
                }
        return None

    @staticmethod
    def create_user(email, fullname, password, phone=None, address=None, is_admin=False, is_active=True):
        """Cria um novo usuário com senha hash."""
        # Verifica se o e-mail ou nome completo já está em uso
        existing_user = Database.execute_query(
            "SELECT * FROM users WHERE email=? OR fullname=?", (email, fullname)
        )

        if existing_user:
            return False, 'Email ou nome de usuário em uso. Escolha outro.'

        # Gera o hash da senha antes de salvar no banco de dados
        hashed_password = generate_password_hash(password)

        # Insere o novo usuário no banco de dados
        success = Database.execute_commit(
            "INSERT INTO users (email, fullname, password, is_admin, is_active, phone, address) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (email, fullname, hashed_password, is_admin, is_active, phone, address)
        )

        return (True, 'Account created successfully! Please login.') if success else (False, 'An error occurred while creating the account.')

    @staticmethod
    def get_user_by_email(email):
        """Obtém um usuário pelo e-mail."""
        user = Database.execute_query(
            "SELECT id, email, fullname, is_admin, is_active, phone, address FROM users WHERE email=?", (email,)
        )
        return user[0] if user else None

    @staticmethod
    def get_user_by_id(user_id):
        """Obtém um usuário específico pelo ID."""
        user = Database.execute_query(
            "SELECT id, email, fullname, is_admin, is_active, phone, address FROM users WHERE id=?", (user_id,)
        )
        return user[0] if user else None

    @staticmethod
    def get_all_users():
        """Obtém todos os usuários do banco de dados."""
        return Database.execute_query("SELECT id, email, fullname, is_admin, is_active, phone, address FROM users ORDER BY fullname")

    @staticmethod
    def update_user(user_id, email, fullname, is_admin, phone=None, address=None):
        """Atualiza as informações de um usuário."""
        return Database.execute_commit(
            "UPDATE users SET email=?, fullname=?, is_admin=?, phone=?, address=? WHERE id=?",
            (email, fullname, is_admin, phone, address, user_id)
        )

    @staticmethod
    def deactivate_user(user_id):
        """Desativa um usuário específico."""
        return Database.execute_commit("UPDATE users SET is_active=0 WHERE id=?", (user_id,))

    @staticmethod
    def activate_user(user_id):
        """Ativa um usuário específico."""
        return Database.execute_commit("UPDATE users SET is_active=1 WHERE id=?", (user_id,))
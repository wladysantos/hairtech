﻿from infra.db import Database

class Service:
    def __init__(self, name, price):
        """Inicializa um objeto de serviço."""
        self.name = name
        self.price = price

    @staticmethod
    def create_service(name, price):
        """Cria um novo serviço."""
        success = Database.execute_commit('''
            INSERT INTO services (name, price)
            VALUES (?, ?)
        ''', (name, price))
        return (True, 'Service created successfully!') if success else (False, 'Failed to create service.')

    @staticmethod
    def get_all_services():
        """Obtém todos os serviços."""
        return Database.execute_query('SELECT * FROM services ORDER BY name')

    @staticmethod
    def get_service_by_id(service_id):
        """Obtém um serviço específico pelo ID."""
        result = Database.execute_query('SELECT * FROM services WHERE id = ?', (service_id,))
        return result[0] if result else None

    @staticmethod
    def update_service(service_id, name, price):
        """Atualiza um serviço existente."""
        success = Database.execute_commit('''
            UPDATE services
            SET name = ?, price = ?
            WHERE id = ?
        ''', (name, price, service_id))
        return (True, 'Service updated successfully!') if success else (False, 'Failed to update service.')

    @staticmethod
    def delete_service(service_id):
        """Deleta um serviço existente."""
        success = Database.execute_commit('DELETE FROM services WHERE id = ?', (service_id,))
        return (True, 'Service deleted successfully!') if success else (False, 'Failed to delete service.')
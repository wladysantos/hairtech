﻿from infra.db import Database

class FinancialEntry:
    def __init__(self, user_id, entry_date, description, amount, entry_type):
        """Inicializa um objeto de lançamento financeiro."""
        self.user_id = user_id
        self.entry_date = entry_date
        self.description = description
        self.amount = amount
        self.entry_type = entry_type

    @staticmethod
    def create_entry(user_id, entry_date, description, amount, entry_type):
        """Cria um novo lançamento financeiro."""
        success = Database.execute_commit('''
            INSERT INTO financial_entries (user_id, entry_date, description, amount, entry_type)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, entry_date, description, amount, entry_type))
        return (True, 'Entry created successfully!') if success else (False, 'Failed to create entry.')

    @staticmethod
    def get_all_entries():
        """Obtém todos os lançamentos financeiros."""
        return Database.execute_query('SELECT * FROM financial_entries')

    @staticmethod
    def get_entry_by_id(entry_id):
        """Obtém um lançamento financeiro específico pelo ID."""
        result = Database.execute_query('SELECT * FROM financial_entries WHERE id = ?', (entry_id,))
        return result[0] if result else None

    @staticmethod
    def update_entry(entry_id, entry_date, description, amount, entry_type):
        """Atualiza um lançamento financeiro existente."""
        success = Database.execute_commit('''
            UPDATE financial_entries
            SET entry_date = ?, description = ?, amount = ?, entry_type = ?
            WHERE id = ?
        ''', (entry_date, description, amount, entry_type, entry_id))
        return (True, 'Entry updated successfully!') if success else (False, 'Failed to update entry.')

    @staticmethod
    def delete_entry(entry_id):
        """Deleta um lançamento financeiro existente."""
        success = Database.execute_commit('DELETE FROM financial_entries WHERE id = ?', (entry_id,))
        return (True, 'Entry deleted successfully!') if success else (False, 'Failed to delete entry.')
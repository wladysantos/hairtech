﻿from flask import jsonify, session, request, redirect, url_for, render_template, flash
from models.user import User
from models.service import Service

class UserController:
    @staticmethod
    def current_user():
        """Retorna o usuário atual se autenticado, caso contrário, None."""
        if 'email' in session:
            return User.get_user_by_email(session['email'])
        return None

    @staticmethod
    def setup_user_routes(app):
        """Configura as rotas de usuário para o aplicativo Flask."""

        @app.route('/')
        def home():
            """Rota para a página inicial."""
            user = UserController.current_user()
            if user:
                services = Service.get_all_services()  # Obtém todos os serviços
                return render_template('home.html', user=user, services=services)
            return redirect(url_for('login'))

        @app.route('/login', methods=['GET', 'POST'])
        def login():
            """Rota para login de usuário."""
            if request.method == 'POST':
                email = request.form['email']
                password = request.form['password']
                user = User.authenticate(email, password)
                if user:
                    session['email'] = email
                    return redirect(url_for('home'))
                flash('Credenciais inválidas. Tente novamente.', 'error')
            return render_template('login.html')

        @app.route('/logout')
        def logout():
            """Rota para logout de usuário."""
            session.pop('email', None)
            return redirect(url_for('login'))

        @app.route('/register', methods=['GET', 'POST'])
        def register():
            """Rota para registrar um novo usuário."""
            if request.method == 'POST':
                email = request.form['email']
                fullname = request.form['fullname']
                password = request.form['password']
                phone = request.form['phone']
                address = request.form['address']

                if not all([email, fullname, password, phone, address]):
                    flash('Preencha todos os campos.', 'danger')
                    return redirect(url_for('register'))

                success, message = User.create_user(email, fullname, password, phone, address)

                if success:
                    flash('Conta criada com sucesso! Faça login.', 'success')
                    return render_template('register.html', redirect_login=True)  # Passa um flag para o template
                else:
                    flash(message, 'danger')
                    return redirect(url_for('register'))
            return render_template('register.html')

        @app.route('/dashboard')
        def dashboard():
            """Rota para o dashboard do usuário."""
            user = UserController.current_user()
            if user:
                return f"Oi, {user['email']}!"
            return redirect(url_for('login'))

        @app.route('/calendar')
        def calendar():
            """Rota para exibir o calendário de agendamentos."""
            user = UserController.current_user()
            if user:
                return render_template('schedules/calendar.html', user=user, is_admin=user['is_admin'])
            return redirect(url_for('login'))
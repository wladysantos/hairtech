﻿from flask import jsonify, request, session
from models.user import User
from models.appointment import Appointment

class AppointmentController:
    @staticmethod
    def current_user():
        """Retorna o usuário atual se autenticado, caso contrário, None."""
        if 'email' in session:
            return User.get_user_by_email(session['email'])
        return None

    @staticmethod
    def setup_appointment_routes(app):
        """Configura as rotas de agendamento para o aplicativo Flask."""

        @app.route('/add_appointment', methods=['POST'])
        def add_appointment():
            """Rota para adicionar um novo agendamento."""
            user = AppointmentController.current_user()
            if not user:
                return jsonify({'status': 'error', 'message': 'User not authenticated!'}), 401

            data = request.json
            datetime_str = data.get('datetime')
            service = data.get('service')

            # Se for admin, utiliza o cliente selecionado; caso contrário, usa o ID do usuário logado.
            if user['is_admin']:
                selected_user_id = data.get('customer')
            else:
                selected_user_id = user['id']

            success, message = Appointment.add_appointment(selected_user_id, datetime_str, service)

            if success:
                return jsonify({'status': 'success', 'message': message}), 200
            else:
                return jsonify({'status': 'error', 'message': message}), 400

        @app.route('/get_appointments', methods=['GET'])
        def get_appointments():
            """Rota para obter todos os agendamentos do usuário atual."""
            user = AppointmentController.current_user()
            if not user:
                return jsonify([])

            events = Appointment.get_appointments_by_user(user['id'])
            return jsonify(events)

        @app.route('/update_appointment', methods=['POST'])
        def update_appointment():
            """Rota para atualizar um agendamento existente."""
            user = AppointmentController.current_user()
            if not user:
                return jsonify({'status': 'error', 'message': 'User not authenticated!'}), 401

            data = request.json
            appointment_id = data.get('id')
            datetime_str = data.get('datetime')
            service = data.get('service')
            selected_user_id = data.get('customer')

            # Validação dos campos obrigatórios
            if not appointment_id or not datetime_str or not service or not selected_user_id:
                return jsonify({'status': 'error', 'message': 'Missing required fields!'}), 400

            success, message = Appointment.update_appointment(appointment_id, selected_user_id, datetime_str, service)

            if success:
                return jsonify({'status': 'success', 'message': message}), 200
            else:
                return jsonify({'status': 'error', 'message': message}), 400

        @app.route('/delete_appointment', methods=['POST'])
        def delete_appointment():
            """Rota para deletar um agendamento existente."""
            user = AppointmentController.current_user()
            if not user:
                return jsonify({'status': 'error', 'message': 'User not authenticated!'}), 401

            appointment_id = request.json.get('id')
            success, message = Appointment.delete_appointment(appointment_id)

            if success:
                return jsonify({'status': 'success', 'message': message}), 200
            else:
                return jsonify({'status': 'error', 'message': message}), 400
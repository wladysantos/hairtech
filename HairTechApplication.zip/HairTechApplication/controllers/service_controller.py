﻿from flask import jsonify
from models.service import Service

class ServiceController:
    @staticmethod
    def setup_service_routes(app):
        """Configura as rotas de serviço para o aplicativo Flask."""

        @app.route('/services', methods=['GET'])
        def get_services():
            """Rota para obter todos os serviços disponíveis."""
            services = Service.get_all_services()
            return jsonify(services)
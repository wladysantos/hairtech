﻿from flask import jsonify, session, request, redirect, url_for, render_template, flash
from datetime import datetime
from models.user import User
from models.financial_entry import FinancialEntry

class FinancialEntryController:
    @staticmethod
    def is_admin():
        """Verifica se o usuário atual é administrador."""
        if 'email' in session:
            user = User.get_user_by_email(session['email'])
            return user if user and user['is_admin'] else None
        return None

    @staticmethod
    def setup_financial_routes(app):
        """Configura as rotas financeiras para o aplicativo Flask."""

        # Registrar o filtro para formatação de data
        @app.template_filter('datetimeformat')
        def datetimeformat(value, format='%d/%m/%Y'):
            """Filtro para formatar uma string de data no template."""
            try:
                # Converte a string para um objeto datetime e formata
                date_obj = datetime.strptime(value, '%Y-%m-%d')
                return date_obj.strftime(format)
            except (ValueError, TypeError):
                # Retorna vazio ou outro valor padrão em caso de erro
                return ''

        @app.route('/financial', methods=['GET'])
        def financial_entries_dashboard():
            """Rota para exibir o dashboard de entradas financeiras."""
            user = FinancialEntryController.is_admin()
            if not user:
                flash('Access denied. Admins only.', 'danger')
                return redirect(url_for('home') if 'email' in session else url_for('login'))

            entries = FinancialEntry.get_all_entries()
            return render_template('financial/entries_dashboard.html', entries=entries, user=user)

        @app.route('/new_edit_entry', methods=['GET', 'POST'])
        @app.route('/new_edit_entry/<int:entry_id>', methods=['GET', 'POST'])
        def new_edit_entry(entry_id=None):
            """Rota para criar ou editar uma entrada financeira."""
            user = FinancialEntryController.is_admin()
            if not user:
                flash('Access denied. Admins only.', 'danger')
                return redirect(url_for('home') if 'email' in session else url_for('login'))

            if request.method == 'POST':
                entry_date = request.form['entry_date']
                description = request.form['description']

                # Conversão da data para o formato yyyy-MM-dd
                try:
                    entry_date = datetime.strptime(entry_date, '%d/%m/%Y').strftime('%Y-%m-%d')
                except ValueError:
                    flash('Invalid date format. Please enter a valid date.', 'danger')
                    return redirect(request.url)

                # Conversão do valor de moeda brasileira para float
                amount_str = request.form['amount'].replace('R$', '').replace('.', '').replace(',', '.').strip()
                try:
                    amount = float(amount_str)
                except ValueError:
                    flash('Invalid amount format. Please enter a valid number.', 'danger')
                    return redirect(request.url)

                entry_type = request.form['entry_type']

                if entry_id:  # Edição de lançamento existente
                    success, message = FinancialEntry.update_entry(entry_id, entry_date, description, amount, entry_type)
                    flash(message, 'success' if success else 'danger')
                else:  # Criação de um novo lançamento
                    success, message = FinancialEntry.create_entry(user['id'], entry_date, description, amount, entry_type)
                    flash(message, 'success' if success else 'danger')

                return redirect(url_for('financial_entries_dashboard') if success else request.url)

            entry_to_edit = None
            if entry_id:
                entry_to_edit = FinancialEntry.get_entry_by_id(entry_id)
                if not entry_to_edit:
                    flash('Entry not found.', 'danger')
                    return redirect(url_for('financial_entries_dashboard'))

            return render_template('financial/new_edit_financial_entry.html', entry=entry_to_edit, user=user)

        @app.route('/admin/delete_entry/<int:entry_id>', methods=['POST'])
        def delete_entry(entry_id):
            """Rota para deletar uma entrada financeira existente."""
            user = FinancialEntryController.is_admin()
            if not user:
                flash('Access denied. Admins only.', 'danger')
                return redirect(url_for('home') if 'email' in session else url_for('login'))

            success, message = FinancialEntry.delete_entry(entry_id)
            flash(message, 'success' if success else 'danger')

            return redirect(url_for('financial_entries_dashboard'))
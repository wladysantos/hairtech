﻿from flask import jsonify, session, request, redirect, url_for, render_template, flash
from models.appointment import Appointment
from models.user import User

class AdminController:
    @staticmethod
    def is_admin():
        """Verifica se o usuário atual é administrador."""
        if 'email' in session:
            user = User.get_user_by_email(session['email'])
            return user if user and user['is_admin'] else None
        return None

    @staticmethod
    def setup_admin_routes(app):
        """Configura as rotas de administração para o aplicativo Flask."""

        @app.route('/admin')
        def admin_dashboard():
            """Rota para o painel de administração."""
            user = AdminController.is_admin()
            if not user:
                flash('Access denied. Admins only.', 'danger')
                return redirect(url_for('home') if 'email' in session else url_for('login'))

            users = User.get_all_users()
            return render_template('users/admin_dashboard.html', users=users, user=user)

        @app.route('/admin/create_user', methods=['GET', 'POST'])
        def create_user():
            """Rota para criação de um novo usuário."""
            user = AdminController.is_admin()
            if not user:
                flash('Access denied. Admins only.', 'danger')
                return redirect(url_for('home') if 'email' in session else url_for('login'))

            if request.method == 'POST':
                email = request.form['email']
                fullname = request.form['fullname']
                password = request.form['password']
                phone = request.form['phone']
                address = request.form['address']
                is_admin = request.form.get('is_admin') == 'on'

                success, message = User.create_user(email, fullname, password, is_admin, True, phone, address)
                flash(message, 'success' if success else 'danger')
                return redirect(url_for('admin_dashboard') if success else request.url)

            return render_template('users/create_user.html', user=user)

        @app.route('/admin/edit_user/<int:user_id>', methods=['GET', 'POST'])
        def edit_user(user_id):
            """Rota para edição de um usuário existente."""
            user = AdminController.is_admin()
            if not user:
                flash('Access denied. Admins only.', 'danger')
                return redirect(url_for('home') if 'email' in session else url_for('login'))

            if request.method == 'POST':
                email = request.form['email']
                fullname = request.form['fullname']
                phone = request.form['phone']
                address = request.form['address']
                is_admin = request.form.get('is_admin') == 'on'

                if User.update_user(user_id, email, fullname, is_admin, phone, address):
                    flash('User updated successfully!', 'success')
                    return redirect(url_for('admin_dashboard'))
                else:
                    flash('An error occurred while updating the user.', 'danger')

            user_to_edit = User.get_user_by_id(user_id)
            if user_to_edit:
                return render_template('users/edit_user.html', user=user_to_edit)
            else:
                flash('User not found.', 'danger')
                return redirect(url_for('admin_dashboard'))

        @app.route('/admin/delete_user/<int:user_id>', methods=['POST'])
        def delete_user(user_id):
            """Rota para desativar um usuário."""
            user = AdminController.is_admin()
            if not user:
                flash('Access denied. Admins only.', 'danger')
                return redirect(url_for('home') if 'email' in session else url_for('login'))

            if User.deactivate_user(user_id):
                flash('User inactivated successfully!', 'success')
            else:
                flash('An error occurred while inactivating the user.', 'danger')

            return redirect(url_for('admin_dashboard'))

        @app.route('/admin/activate_user/<int:user_id>', methods=['POST'])
        def activate_user(user_id):
            """Rota para ativar um usuário."""
            user = AdminController.is_admin()
            if not user:
                flash('Access denied. Admins only.', 'danger')
                return redirect(url_for('home') if 'email' in session else url_for('login'))

            if User.activate_user(user_id):
                flash('User activated successfully!', 'success')
            else:
                flash('An error occurred while activating the user.', 'danger')

            return redirect(url_for('admin_dashboard'))

        @app.route('/admin/get_customers', methods=['GET'])
        def get_customers():
            """Rota para obter uma lista de clientes."""
            user = AdminController.is_admin()
            if not user:
                return jsonify({'status': 'error', 'message': 'Access denied. Admins only.'}), 403

            users = User.get_all_users()
            customers = [{'id': u['id'], 'fullname': u['fullname'], 'email': u['email']} for u in users]
            return jsonify(customers)

        @app.route('/admin/get_all_appointments', methods=['GET'])
        def get_all_appointments():
            """Rota para obter todas as consultas agendadas."""
            user = AdminController.is_admin()
            if not user:
                return jsonify({'status': 'error', 'message': 'Access denied. Admins only.'}), 403

            success, result = Appointment.get_all_appointments()

            if not success:
                return jsonify({'status': 'error', 'message': result}), 500 if result == 'Internal Server Error.' else 404

            return jsonify(result)